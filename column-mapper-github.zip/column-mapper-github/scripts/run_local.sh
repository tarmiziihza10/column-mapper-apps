
#!/usr/bin/env bash
# One-click launcher (macOS/Linux) - localhost only
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR/.."
python -m streamlit run column_mapper_app_v3.py --server.address=127.0.0.1
